﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.IO;

namespace GiphyHome
{
    public class GiphyService
    {
        private string _key;
        private string _baseUrl;
        public GiphyService()
        {
            var config = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json").Build().GetSection("AppSettings");
            _key = config["ApiKey"];
            _baseUrl = config["BaseUrl"];
        }

        public async Task<IEnumerable<string>> GetTerndingGifUrl(int limit)
        {

            using var client = new HttpClient();
            HttpResponseMessage response = client.GetAsync(_baseUrl + "trending?api_key=" + _key + $"&limit={limit}" + "&rating=g").Result;

            response.EnsureSuccessStatusCode();
            var msg = await response.Content.ReadAsStringAsync();
            var result = JsonConvert.DeserializeObject<Models.Root>(msg);
            return result.data.Select(item => item.url).ToList();
        }

        public async Task<IEnumerable<string>> SearchGif(string str)
        {
            using var client = new HttpClient();
            HttpResponseMessage response = client.GetAsync(_baseUrl + $"search?api_key={_key}" + $"&q={str}" + "&limit=25&offset=0&rating=g&lang=en").Result;
            response.EnsureSuccessStatusCode();
            var msg = await response.Content.ReadAsStringAsync();
            var result = JsonConvert.DeserializeObject<Models.Root>(msg);
            return result.data.Select(item => item.url).ToList();
        }
    }
}
